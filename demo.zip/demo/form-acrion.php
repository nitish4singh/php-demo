<?php
include'database/connection.php';
$name=$rolllno =$class="";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nameq =$_POST["name"];
  $rolllno =$_POST["rollno"];
  $class =$_POST["class"];
  
  $sql = "INSERT INTO `student` (`name`, `rollno`, `class`) VALUES ('$nameq', '$rolllno', '$class')";
  
  if (mysqli_query($conn, $sql)) {
    echo"echo <script>
    window.location.href='/demo/index.php';
    alert('recoard has been Added successfully');
    </script>";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }


}
?>