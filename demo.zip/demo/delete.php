<?php
include'database/connection.php';
$id="";
if(isset($_GET['delete']))
$id = $_GET['delete'];
// sql to delete a record
$sql = "DELETE FROM student WHERE id=$id";
$res= mysqli_query($conn,$sql);
if ($res) {
    echo"echo <script>
    window.location.href='/demo/index.php';
    alert('recoard has been deleted');
    </script>";
}

?>