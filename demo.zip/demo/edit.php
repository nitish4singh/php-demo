<?php
include'database/connection.php';

$nameq=$rolllno =$class=$id="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    $nameq = $_POST["name"];

    $rolllno = $_POST["rollno"];

    $class = $_POST["class"];
  
  $sql = "UPDATE `student` SET `name`='$nameq',
	`rollno`='$rolllno',
  `class`='$class' WHERE id=$id";
  
  if (mysqli_query($conn, $sql)) {
    echo"echo <script>
    window.location.href='/demo/index.php';
    alert('recoard has been updated');
    </script>";
   

  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }


}
?>